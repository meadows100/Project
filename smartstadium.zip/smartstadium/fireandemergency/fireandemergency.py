"""Fire and Emergency Management publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
from datetime import datetime
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet

def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nFire and Emergency Management Connected")
    else:
        print("\nFire and Emergency Management was unable to connect, failed with error", return_code)


def on_disconnect(client, userdata, r_c):
    """On disconnect, log to file"""
    with open("fireandemergency.log", "a", encoding="utf-8") as output_file:
        lognote = "Fire and Emergency Management disconnected with error " + str(r_c)
        today = datetime.now()
        dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
        output_file.writelines(lognote + " @ " + str(dtstamp) + "\n")


def publish(client, topic, msg, qos):
    """Publish message to TOPIC"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    client.publish(topic, payload, qos, False)
    time.sleep(2)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC = "emergencystatus"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Fire and Emergency Management OK"
LWM = "Fire and Emergency Management Offline"
CLIENT = mqtt.Client("Fire and Emergency Management")  # Defines client device


# Set Last Will message on TOPIC
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC,elwm,QOS_LEVEL,retain=False)


# Check network connection, then connect to broker
try:
    CLIENT.connect(BROKER, PORT)
    CLIENT.on_connect = on_connect
    CLIENT.on_disconnect = on_disconnect
except:
    print("No network connection, exiting")
    exit()


# This logs the transaction.
with open("fireandemergency.log", "a", encoding="utf-8") as output_file:
    lognote = "Fire and Emergency Management Successfully connected"
    today = datetime.now()
    dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
    output_file.writelines(lognote + " @ " + str(dtstamp) + "\n")
publish(CLIENT, TOPIC, MESG, QOS_LEVEL)


# Check message buffers
CLIENT.loop_start()
time.sleep(2)


# Give the user a way to send help (HELP) or end the program (Enter)
while True:
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    elif inp.upper() == "HELP":
        publish(CLIENT, TOPIC, "HELP", QOS_LEVEL)
        print("\nAlarm triggered.  Enter HELP to sound alarm again if required.")
    else:
        print("\nInvalid command: " + inp)
