"""Automated Lighting Controls publish online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nAutomated Lighting Controls Connected")
        pub(client, TOPIC7, MESG, QOS_LEVEL)
    else:
        print("\nAutomated Lighting Controls Not connected")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC7"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC7 = "lightsstatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Automated Lighting Controls OK"
LWM = "Automated Lighting Controls Offline"


# Define client device
client = mqtt.Client("Automated Lighting Controls")


# Set Last Will message on TOPIC7
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC7, elwm, QOS_LEVEL, retain=False)


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
