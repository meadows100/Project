"""Stadium Kiosk publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import getpass
import hashlib
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nKiosk Connected")
        pub(client, TOPIC3, MESG, QOS_LEVEL)
    else:
        print("\nKiosk Not connected")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC3"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


def firmware_login():
    """give user the choice to enter the firmware interface"""
    firminp = input("\nEnter f to enter Kiosk firmware:\n")
    if firminp == "f":
        wrongpassword = 0
        authenticate(client, wrongpassword)
    else:
        print("Firmware skipped, connecting to broker...")
        boot_up()


def authenticate(client, wrongpassword):
    """Check password file to authenticate, and authenticate if passed"""
    # Hide password while entering
    pwd = getpass.getpass("Welcome to Kiosk Firmware Admin Interface.\n"
                          "\nEnter password to login to embedded firmware: \n")
    # Hash the password
    pwd = hashlib.sha256(pwd.encode('utf-8')).hexdigest()
    # Open the password file and convert it to string for comparison
    pwfile = open("readpwd.txt", "r", encoding="utf-8")
    pwstring = str(pwfile.readline()).lower()
    # Compare given password with stored password
    if pwstring == pwd:
        print("Authentication Passed!")
        print("\nWelcome to the Kiosk Firmware")
        print("Firmware is v. 10.2.3")
        firminp = input("Enter k to continue to boot: \n")
        if firminp != "k":
            print("Incorrect option entered - rebooting...")
            time.sleep(2)
            firmware_login()
        else:
            boot_up()
    else:
        wrongpassword = wrongpassword + 1
        print("Authentication failed")
        if wrongpassword < 3:
            authenticate(client, wrongpassword)
        else:
            print("Maximum 3 attempts exceeded.  Connecting to broker...")
            boot_up()


def boot_up():
    """after firmware login, boot to connect to broker"""
    # Set Last Will message on TOPIC3
    elwm = CIPHER.encrypt(LWM.encode()).decode()
    client.will_set(TOPIC3, elwm, QOS_LEVEL, retain=False)
    time.sleep(2)


# Set Constants for server
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC3 = "kioskstatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Kiosk OK"
LWM = "Kiosk Offline"


# Define client device
client = mqtt.Client("kiosk")


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()


# Begin the program
firmware_login()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
