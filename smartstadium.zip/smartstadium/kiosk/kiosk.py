"""Stadium Kiosk publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import getpass
import hashlib
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nKiosk Connected")
    else:
        print("\nKiosk was unable to connect, failed with error", return_code)


def publish(client, topic, msg, qos):
    """Publish message to TOPIC"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    client.publish(topic, payload, qos, False)
    time.sleep(2)


def firmware_login():
    """give user the choice to enter the firmware interface"""
    firminp = input("\nEnter f to enter Kiosk firmware:\n")
    if firminp == "f":
        wrongpassword = 0
        authenticate(wrongpassword)
    else:
        print("Firmware skipped, connecting to broker...")
        boot_up()


def authenticate(wrongpassword):
    """Check password file to authenticate, and authenticate if passed"""
    # Hide password while entering
    pwd = getpass.getpass("Welcome to Kiosk Firmware Admin Interface.\n"
                          "\nEnter password to login to embedded firmware: \n")
    # Hash the password
    pwd = hashlib.sha256(pwd.encode('utf-8')).hexdigest()
    # Open the password file and convert it to string for comparison
    pwfile = open("readpwd.txt", "r", encoding="utf-8")
    pwstring = str(pwfile.readline()).lower()
    # Compare given password with stored password
    if pwstring == pwd:
        print("Authentication Passed!")
        print("\nWelcome to the Kiosk Firmware")
        print("Firmware is v. 10.2.3")
        firminp = input("Enter k to continue to boot: \n")
        if firminp != "k":
            print("Incorrect option entered - rebooting...")
            time.sleep(2)
            firmware_login()
        else:
            boot_up()
    else:
        wrongpassword = wrongpassword + 1
        print("Authentication failed")
        if wrongpassword < 3:
            authenticate(wrongpassword)
        else:
            print("Maximum 3 attempts exceeded.  Connecting to broker...")
            boot_up()


def boot_up():
    """after firmware login, boot to connect to broker"""
    publish(CLIENT, TOPIC, MESG, QOS_LEVEL)
    time.sleep(2)


# Set Constants for server
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC = "kioskstatus"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Kiosk OK"
LWM = "Kiosk Offline"
CLIENT = mqtt.Client("kiosk")  # Defines client device


# Check network connection, then connect to broker
try:
    CLIENT.connect(BROKER, PORT)
    CLIENT.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()


# Set Last Will message on TOPIC
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC, elwm, QOS_LEVEL, retain=False)

# Begin the program
firmware_login()

while True:
    # Check message buffers
    CLIENT.loop_start()
    time.sleep(2)
    # Give the user a way to end the program
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
