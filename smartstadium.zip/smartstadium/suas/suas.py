"""Small Unmanned Aircraft System (sUAS) publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import random
from random import randrange
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nSmall Unmanned Aircraft System (sUAS) Connected\n")
        pub(client, TOPIC5, MESG, QOS_LEVEL)
        # Subscribe to TOPIC with QOS = 1
        sub(client, TOPIC14, QOS_LEVEL)
    else:
        print("\nSmall Unmanned Aircraft System (sUAS) Not connected\n")


def sub(client, topic, qos):
    """Subscribe to TOPIC14"""
    client.subscribe(topic, qos)
    pub(client, TOPIC14, "Simulated Encrypted Report Messages:", QOS_LEVEL)


def on_message(client, userdata, message):
    """On receiving new message:
    Decrypt message, convert to integser, display report to the user,
    then kick off publish function to send again"""
    decrypted_message = CIPHER.decrypt(message.payload)
    print(str(decrypted_message.decode("utf-8")))
    if randrange(4) == 3:
        aword = (random.choice(names))
        bword = (random.choice(nouns))
        cword = (random.choice(area))
        dword = (random.choice(blocks))
        sentence = ("sUAS: " + aword + " are " + bword + " in section " + cword + dword)
    else:
        sentence = "sUAS: No message"
    pub(client, TOPIC14, sentence, QOS_LEVEL)


def pub(client, topic, msg, qos):
    """Publish message to TOPIC5"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants for server
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC5 = "suasstatus"
TOPIC14 = "suasreport"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Small Unmanned Aircraft System OK"
LWM = "Small Unmanned Aircraft System Offline"


# Declaring names, verbs and nouns for simulated report message
names = ["Away fans", "Home fans"]
nouns = ["damaging the stadium", "taking drugs", "showing aggression", \
"fighting", "inappropriately taunting"]
area = ["A", "B", "C", "D", "E", "F", "G", "H"]
blocks = ["1", "2", "3", "4", "5", "6", "7", "8"]


# Define server device
client = mqtt.Client("suas")


# Set encrypted Last Will message on TOPIC5
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC5,elwm,QOS_LEVEL,retain=False)


# Check network connection, then connect to broker, and register callbacks to functions
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
    client.on_message = on_message
except:
    print("No network connection, exiting")
    exit()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
