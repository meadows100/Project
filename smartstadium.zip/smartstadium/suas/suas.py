"""Small Unmanned Aircraft System (sUAS) publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import random
from random import randrange
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nSmall Unmanned Aircraft System (sUAS) Connected\n")
        # Collect messages by subscribing to TOPIC_B, before updated message is to TOPIC_A
        subscribe(client, TOPIC_B, QOS_LEVEL)
        publish(client, TOPIC_A, MESG, QOS_LEVEL)
    else:
        print("\nSmall Unmanned Aircraft System (sUAS) was unable to connect, failed with error", return_code)


def on_message(client, userdata, message):
    """On receiving new message:
    Decrypt message, convert to integser, display report to the user,
    then kick off publish function to send again"""
    decrypted_message = CIPHER.decrypt(message.payload)
    print(str(decrypted_message.decode("utf-8")))
    if randrange(4) == 3:
        aword = (random.choice(names))
        bword = (random.choice(nouns))
        cword = (random.choice(area))
        dword = (random.choice(blocks))
        sentence = ("sUAS: " + aword + " are " + bword + " in section " + cword + dword)
    else:
        sentence = "sUAS: No message"
    publish(client, TOPIC_B, sentence, QOS_LEVEL)


def publish(client, topic, msg, qos):
    """Publish message to TOPIC_A"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    client.publish(topic, payload, qos, False)
    time.sleep(2)


def subscribe(client, topic, qos):
    """Subscribe to TOPIC_B with QOS level 1"""
    client.subscribe(topic, qos)
    publish(client, TOPIC_B, "Simulated Encrypted Report Messages:", QOS_LEVEL)


# Set Constants for server
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC_A = "suasstatus"
TOPIC_B = "suasreport"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Small Unmanned Aircraft System OK"
LWM = "Small Unmanned Aircraft System Offline"
CLIENT = mqtt.Client("suas")  # Defines server device

# Declaring names, verbs and nouns in lists for simulated report message
names = ["Away fans", "Home fans"]
nouns = ["damaging the stadium", "taking drugs", "showing aggression", \
"fighting", "inappropriately taunting"]
area = ["A", "B", "C", "D", "E", "F", "G", "H"]
blocks = ["1", "2", "3", "4", "5", "6", "7", "8"]


# Set encrypted Last Will message on TOPIC_A
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC_A,elwm,QOS_LEVEL,retain=False)


# Check network connection, then connect to broker, and register callbacks to functions
try:
    CLIENT.connect(BROKER, PORT)
    CLIENT.on_connect = on_connect
    CLIENT.on_message = on_message
except:
    print("No network connection, exiting")
    exit()

while True:
    CLIENT.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
