"""Stadium Entrance Equipment publishes online/offline status via the public broker
and sends a last will message in case of ungraceful disconnection
"""

import time
import getpass
import hashlib
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet
import mysql.connector


def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nStadium Entrance Equipment Connected")
        publish(client, TOPIC, MESG, QOS_LEVEL)
    else:
        print("\nStadium Entrance Equipment was unable to connect, failed with error", return_code)


def publish(client, topic, msg, qos):
    """Publish message to TOPIC"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    client.publish(topic, payload, qos, False)
    time.sleep(2)


def login():
    """Obtain username and password from user input and feed it to check_login() function."""
    username = input("\nStadium Entrance Controls\n \nPlease enter your username: ")
    password = getpass.getpass("\nPlease enter your password.  \
    Password must be at between 8 and 30 characters and should include at least 3 of the following \
    (uppercase, lowercase, number, special character including: [‘, ~, !, @, #, $, %, ^, *, _, -, +, =, {, }, /, ., ?, |, (space)].  \
    Please note your password will be hidden while typing:\n")
    check_login(username, password)


def check_login(given_username, given_password):
    """Apply validation checks to username and password"""
    given_username = given_username.lower()
    username_status = check_username(given_username)
    password_status = check_password(given_password)
    if username_status != "Username correct.":
        print(username_status + " Try again")
        login()
    else:
        if password_status != "OK":
            print("Login Failed! Error in Password field: " + password_status + ", try again")
            login()
        else:
            if given_username == given_password.lower():
                print("Password cannot be the same as the username.")
            else:
                # Hash password before attempting to match the one saved in DB.
                given_password = hashlib.sha256(given_password.encode('utf-8')).hexdigest()
                # Build SQL string and then use command to compare with data from the database.
                sql = "SELECT userID, userName, password, firstName, lastName, lockoutStatus, role, email, failedattempts FROM staff WHERE userName = %s and password = %s and role = 'Turnstile'"
                CURSOR.execute(sql, (given_username, given_password))
                fetch_results = CURSOR.fetchall()
                if CURSOR.rowcount != 1:
                    # If there is no match, turn user away
                    print("Access denied, please try again.")
                    login()
                else:
                    print("Username and Password correct!")
                    # Display record in a nice way
                    for row in fetch_results:
                        print("\nUserName: ", row[1])
                        print("Email: ", row[7])
                        print("Role: ", row[6])


def check_username(given_username):
    """Check username exists in database"""
    if len(given_username) < 1:
        user_status = "Username cannot be empty."
    elif len(given_username) > 30:
        user_status = "Username is too long, please enter max 30 characters."
    else:
        for char in given_username:
            # Check username only contains letters.
            if char.islower():
                user_status = "OK"
            else:
                user_status = "Invalid character in username, please only use a-z characters."
                break
        if user_status == "OK":
            # Build sql string and then execute query to check that username exists.
            sqlstring = "SELECT userName FROM staff WHERE userName = %s"
            CURSOR.execute(sqlstring, (given_username, ))
            fetch_results = CURSOR.fetchall()
            if CURSOR.rowcount == 1:
                user_status = "Username correct."
            else:
                user_status = "Username does not exist."
    return (user_status)


def check_password(given_password):
    """Checks that password meets complexity requirements"""
    # List of allowed special characters.
    specialchars = ["-", "~", "_", "#", "@", "$", "%", "^", "*", "!", "'", "+", "=", "{", "}", "/", ".", "?", "|", " "]
    lower_case = 0
    upper_case = 0
    special = 0
    digit = 0
    invalid_char = 0
    pwdlen = len(given_password)
    if pwdlen < 8 or pwdlen > 30:
        pwd_status = "Wrong Length, please enter a password between 8 and 30 characters."
    else:
        # Counters for determining if password contains at least 3 of the 4 character groups
        for char in given_password:
            if char.isdigit():
                digit = 1
            elif char.isupper():
                upper_case = 1
            elif char.islower():
                lower_case = 1
            elif char in specialchars:
                special = 1
            else:
                invalid_char = 1
        total_char_groups = lower_case + upper_case + digit + special
        if invalid_char == 1:
            pwd_status = "Password contains an illegal character, please try again."
        else:
            if total_char_groups < 3:
                # Not enough character groups in password
                pwd_status = "Password must contain 3 of the 4 character groups (digit 0-9, uppercase a-z, lowercase a-z, special)."
            else:
                pwd_status = "OK"
    return (pwd_status)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
DB = 'use sql8596453'
PORT = 1883
TOPIC = "entrancestatus"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Stadium Entrance Equipment OK"
LWM = "Stadium Entrance Equipment Offline"
CLIENT = mqtt.Client("Stadium Entrance")  # Defines client device
CONNECTION = mysql.connector.connect(host='sql8.freesqldatabase.com',
                                     user='sql8596453', password='Dp8IlPJvcl')
CURSOR = CONNECTION.cursor()


# Connect to MySQL database
CURSOR.execute("CREATE DATABASE IF NOT EXISTS sql8596453")
CURSOR.execute(DB)


# Set Last Will message on TOPIC
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC, elwm, QOS_LEVEL, retain=False)


# Check network connection, then connect to broker
try:
    CLIENT.connect(BROKER, PORT, 0)
    CLIENT.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()


# Begin the program
login()


while True:
    # Check message buffers
    CLIENT.loop_start()
    time.sleep(2)
    # Give the user a way to end the program
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
