"""Stadium Entrance Equipment publishes online/offline status via the public broker
and sends a last will message in case of ungraceful disconnection
"""

from datetime import datetime
import time
import getpass
import hashlib
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet
import mysql.connector


# Create a connection to MySQL database.
conn = mysql.connector.connect(host='sql8.freesqldatabase.com', \
user='sql8596453', password='Dp8IlPJvcl')
curs = conn.cursor()
curs.execute("CREATE DATABASE IF NOT EXISTS sql8596453")
DB = 'use sql8596453'
curs.execute(DB)


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nStadium Entrance Equipment Connected")
        pub(client, TOPIC12, MESG, QOS_LEVEL)
    else:
        print("\nStadium Entrance Equipment Not connected")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC12"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


def login():
    """Obtain username and password from user input and feed it to check_login() function."""
    username = input("\nStadium Entrance Controls\n \nPlease enter your username: ")
    password = getpass.getpass("\nPlease enter your password.  \
    Password must be at between 8 and 30 characters and should include at least 3 of the following \
    (uppercase, lowercase, number, special character including: [‘, ~, !, @, #, $, %, ^, *, _, -, +, =, {, }, /, ., ?, |, (space)].  \
    Please note your password will be hidden while typing:\n")
    check_login(username, password)


def check_login(myusername, mypassword):
    """Log in existing user."""
    # Check username and password for validation.
    myusername = myusername.lower()
    if check_username(myusername) != "Username correct.":
        print(check_username(myusername) + " Try again")
        login()
    else:
        if check_password(mypassword) != "Valid":
            print("Login Failed! Error in Password field: " \
            + check_password(mypassword) + " Try again")
            login()
        else:
            if myusername == mypassword.lower():
                print("Password cannot be the same as the username.")
            else:
                # Hash password before attempting to match the one saved in DB.
                mypassword = hashlib.sha256(mypassword.encode('utf-8')).hexdigest()
                # Build SQL string and then use command to compare with data from the database.
                sql = "SELECT userID, userName, password, firstName, lastName, lockoutStatus, role, email, failedattempts FROM staff WHERE userName = %s and password = %s and role = 'Turnstile'"
                curs.execute(sql, (myusername, mypassword))
                myresult = curs.fetchall()
                if curs.rowcount != 1:
                    # If there is no match, turn user away
                    print("Access denied, please try again.")
                    login()
                    lognote = " failed to login"
                else:
                    lognote = " successfully logged in"
                    print("Username and Password correct!")
                    # Display record in a nice way
                    for row in myresult:
                        print("\nUserName: ", row[1])
                        print("Email: ", row[7])
                        print("Role: ", row[6])
                        # This logs the transaction in python.log.
                with open("entrance.log", "a", encoding="utf-8") as output_file:
                    today = datetime.now()
                    dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
                    output_file.writelines(myusername + lognote + " @ " + str(dtstamp) + "\n")


def check_username(checkusername):
    """Check if the user username already exists"""
    if len(checkusername) < 1:
        userstatus = "Username cannot be empty."
    elif len(checkusername) > 30:
        userstatus = "Username is too long, please enter max 30 characters."
    else:
        for char in checkusername:
            # Check username only contains letters.
            if char.islower():
                userstatus = "Valid"
            else:
                userstatus = "Invalid character in username, please only use a-z characters."
                break
        if userstatus == "Valid":
            # Build sql string and then execute query to check that username exists.
            sql = "SELECT userName FROM staff WHERE userName = %s"
            curs.execute(sql, (checkusername, ))
            myresult = curs.fetchall()
            if curs.rowcount == 1:
                userstatus = "Username correct."
            else:
                userstatus = "Username does not exist."
    return(userstatus)


def check_password(checkpassword):
    """Checks password complexity requirements are met. E.g. min 8 characters, max 30 characters."""
    # Allowable special characters.
    specialchars = ["‘", "~", "!", "@", "#", "$", "%", "^", "*", "_", "-", "+", "=", "{", "}", "/", ".", "?", "|", " "]
    special = 0
    digitcnt = 0
    lowercnt = 0
    uppercnt = 0
    invalidchar = 0
    pwdlen = len(checkpassword)
    if pwdlen < 8 or pwdlen > 30:
        pwdstatus = "Wrong Length, please enter a password between 8 and 30 characters."
    else:
        # Counters for calculation to see if at least \
        # 3 of the 4 character groups are involved in building password.
        for char in checkpassword:
            if char.isdigit():
                digitcnt = 1
            elif char.isupper():
                uppercnt = 1
            elif char.islower():
                lowercnt = 1
            elif char in specialchars:
                special = 1
            else:
                invalidchar = 1
        mytotal = lowercnt + uppercnt + digitcnt + special
        if invalidchar == 1:
            pwdstatus = "Password contains an illegal character, please try again."
        else:
            if mytotal < 3:
                # Not enough character groups in password
                pwdstatus = "Password must contain 3 of the 4 character groups \
                (digit 0-9, uppercase a-z, lowercase a-z, special)."
            else:
                pwdstatus = "Valid"
    return(pwdstatus)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC12 = "entrancestatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Stadium Entrance Equipment OK"
LWM = "Stadium Entrance Equipment Offline"


# Define client device
client = mqtt.Client("Stadium Entrance")


# Set Last Will message on TOPIC12
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC12, elwm, QOS_LEVEL, retain=False)


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT, 0)
    client.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()

# Begin the program
login()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
