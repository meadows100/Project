"""Smart Grid publishes online/offline status via the public broker and sends a last will message in case of ungraceful disconnection (on TOPIC9)
It also sends an encrypted, cumulative meter reading, which keeps track even after disconnection (on TOPIC13)"""

import time
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("Connected\n")
        pub(client, TOPIC13, 1, QOSS)
    else:
        print("Not connected\n")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC13"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    # retain flag set to true if topic = meterreading, so to keep a continuous loop and a growing number.
    client.publish(topic, out_message, qos, True)
    time.sleep(2)


# Set Constants for server
QOSS = 1
BROKER = "3.64.122.91"
PORT = 1883
TOPIC13 = "meterreading"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)

# Define server device
client = mqtt.Client("Smart Grid")
mesg = "Smart Grid OK"


# Check network connection.  Then setup client, connect to broker, and register function callbacks

client.connect(BROKER, PORT)
client.on_connect = on_connect


# Check message buffers

while True:
    client.loop_start()
    time.sleep(2)
