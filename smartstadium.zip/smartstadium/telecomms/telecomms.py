"""Telecommunications publish online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nTelecommunications Connected")
        publish(client, TOPIC, MESG, QOS_LEVEL)
    else:
        print("\nTelecommunications was unable to connect, failed with error", return_code)


def publish(client, topic, msg, qos):
    """Publish message to TOPIC"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    client.publish(topic, payload, qos, False)
    time.sleep(2)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC = "telecommsstatus"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Telecommunications OK"
LWM = "Telecommunications Offline"
CLIENT = mqtt.Client("Telecommunications")  # Defines client device


# Set Last Will message on TOPIC
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC, elwm, QOS_LEVEL, retain=False)


# Check network connection, then connect to broker
try:
    CLIENT.connect(BROKER, PORT)
    CLIENT.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()

CLIENT.connect(BROKER, PORT)
CLIENT.on_connect = on_connect


while True:
    # Check message buffers
    CLIENT.loop_start()
    time.sleep(2)
    # Give the user a way to end the program
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
