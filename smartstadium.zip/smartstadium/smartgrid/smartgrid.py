"""Smart Grid publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection (on TOPIC_A)
It also sends an encrypted, cumulative meter reading, 
which keeps track even after disconnection (on TOPIC_B)
"""

import time
from random import randrange
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet

def on_connect(client, userdata, flags, return_code):
    """Check connection"""
    if return_code == 0:
        print("\nSmart Grid Connected\n")
        # Subscribe to its own TOPIC with QOS level 1
        subscribe(client, TOPIC_B, QOS_LEVEL)
        publish(client, TOPIC_A, MESG, QOS_LEVEL)
    else:
        print("\nSmart Grid was unable to connect, failed with error", return_code)


def subscribe(client, topic, qos):
    """Subscribe to TOPIC_B with QOS level 1"""
    client.subscribe(topic, qos)


def on_message(client, userdata, message):
    """On receiving new message:
    Decrypt message, convert to integser, display the units to the user,
    then kick off publish function to send again"""
    decrypted_message = CIPHER.decrypt(message.payload)
    msg = int(decrypted_message.decode("utf-8"))
    print("Smart Grid Meter Reading: "
          " = ", str(decrypted_message.decode("utf-8")))
    # Generate a random number to simulate a running meter total
    msg = msg + randrange(10)
    # Publish new total in a loop
    publish(client, TOPIC_B, msg, QOS_LEVEL)


def publish(client, topic, msg, qos):
    """Publish message to TOPIC_A and TOPIC_B"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    payload = encrypted_message.decode()
    # Retain flag set to true if topic = meterreading, \
    # so to keep a continuous loop and a growing number.
    # Set to false if smartgridstatus so to get an immediate \
    # accurate reading of when it is online or offline.
    if topic == "meterreading":
        client.publish(topic, payload, qos, True)
    else:
        client.publish(topic, payload, qos, False)
    time.sleep(2)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC_A = "smartgridstatus"
TOPIC_B = "meterreading"
ENCRYPTION_KEY = b'Y1k_12xlCgOb33h4U2xp9ViOdvLRvSjVh4u2lUSLkVE='
CIPHER = Fernet(ENCRYPTION_KEY)
MESG = "Smart Grid OK"
LWM = "Smart Grid Offline"
CLIENT = mqtt.Client("Smart Grid")  # Defines client device


# Set encrypted Last Will message on TOPIC_A
elwm = CIPHER.encrypt(LWM.encode()).decode()
CLIENT.will_set(TOPIC_A, elwm, QOS_LEVEL, retain=False)


# Check network connection.  Then setup client, connect to broker, and register function callbacks
try:
    CLIENT.connect(BROKER, PORT)
    CLIENT.on_connect = on_connect
    CLIENT.on_message = on_message
except:
    print("No network connection, exiting")
    exit()

while True:
# Check message buffers
    CLIENT.loop_start()
    time.sleep(2)
    # Give the user a way to end the program
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        CLIENT.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
