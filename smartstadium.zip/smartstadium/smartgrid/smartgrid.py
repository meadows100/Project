"""Smart Grid publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection (on TOPIC9)
It also sends an encrypted, cumulative meter reading, 
which keeps track even after disconnection (on TOPIC13)
"""

import time
from random import randrange
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet

def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nSmart Grid Connected\n")
        # Subscribe to its own TOPIC with QOS = 1
        sub(client, TOPIC13, QOS_LEVEL)
        pub(client, TOPIC9, MESG, QOS_LEVEL)
    else:
        print("\nNot connected\n")


def sub(client, topic, qos):
    """Subscribe to TOPIC13 with QOS = 1"""
    client.subscribe(topic, qos)


def on_message(client, userdata, message):
    """On receiving new message:
    Decrypt message, convert to integser, display the units to the user,
    then kick off publish function to send again"""
    decrypted_message = CIPHER.decrypt(message.payload)
    msg = int(decrypted_message.decode("utf-8"))
    print("Smart Grid Meter Reading: "
          " = ", str(decrypted_message.decode("utf-8")))
    # Generate a random number to simulate a running meter total
    msg = msg + randrange(10)
    # Publish new total in a loop
    pub(client, TOPIC13, msg, QOS_LEVEL)


def pub(client, topic, msg, qos):
    """Publish message to TOPIC9 and TOPIC13"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    # Retain flag set to true if topic = meterreading, \
    # so to keep a continuous loop and a growing number.
    # Set to false if smartgridstatus so to get an immediate \
    # accurate reading of when it is online or offline.
    if topic == "meterreading":
        client.publish(topic, out_message, qos, True)
    else:
        client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants
QOS_LEVEL = 1
BROKER = "3.65.137.17"
PORT = 1883
TOPIC9 = "smartgridstatus"
TOPIC13 = "meterreading"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Smart Grid OK"
LWM = "Smart Grid Offline"


# Define client device
client = mqtt.Client("Smart Grid")


# Set encrypted Last Will message on TOPIC9
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC9, elwm, QOS_LEVEL, retain=False)


# Check network connection.  Then setup client, connect to broker, and register function callbacks
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
    client.on_message = on_message
except:
    print("No network connection, exiting")
    exit()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
