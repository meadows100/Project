"""Reset Database deletes the db and rebuilds it, including data"""
import time
import mysql.connector
from mysql.connector import errorcode
from datetime import datetime
import getpass
import hashlib


# Check network connection, then create a connection to MySQL database.
try:
    conn = mysql.connector.connect(host='sql8.freesqldatabase.com', user='sql8596453', password='Dp8IlPJvcl')
    curs = conn.cursor()
    curs.execute("CREATE DATABASE IF NOT EXISTS sql8596453")
    db = 'use sql8596453'
    curs.execute(db)
except:
    print("No network connection, exiting")
    exit()


def register():
    # Get password of all 5 users through getpass, which hides the keyinput.
    passwords = []
    i = 0
    users = ("rmatthews", "mjackson", "psmith", "jmitchell", "ljones")
    new_password = ""
    while i < 5:
        new_password = getpass.getpass("\n\n" + str(i + 1) + ". Please enter a password for " + users[i] + ".  Password must be between 8 and 30 characters and contain at least 3 of the following: uppercase, lowercase, number, special character including: [‘, ~, !, @, #, $, %, ^, *, _, -, +, =, {, }, /, ., ?, |, (space)].  Please note that the passwords are hidden while typing: \n")
        if check_password(new_password) != "Valid":
            print("Bad password for " + users[i] + ". " + check_password(new_password) + ", please try again.")
        else:
            new_password = hashlib.sha256(new_password.encode('utf-8')).hexdigest()
            print("Good password")
            passwords.append(new_password)
            i = i + 1
    resetdb(passwords[0], passwords[1], passwords[2], passwords[3], passwords[4])


def resetdb(password1, password2, password3, password4, password5):
    """Resets the 'staff' database.  Deletes existing and rebuilds a new, clean database.  This will be removed from a production build."""
    curs.execute("DROP table staff")
    conn.commit()
    curs.execute("CREATE TABLE IF NOT EXISTS staff(userID INT(5) UNSIGNED NOT NULL AUTO_INCREMENT UNIQUE, userName VARCHAR(10) NOT NULL, firstName VARCHAR(30) NOT NULL, lastName VARCHAR(30) NOT NULL, email VARCHAR(64) UNIQUE NOT NULL, password VARCHAR(64) NOT NULL, failedAttempts TINYINT(1), lockoutStatus TINYINT(1), role ENUM('CCTV', 'Screen', 'Turnstile', 'Lights Admin', 'Admin') NOT NULL, PRIMARY KEY(userID))")
    conn.commit()
    # Build SQL string and then put fields into the database (W3Schools, N.D.)
    sql = "INSERT INTO staff (username, firstName, lastName, email, password, failedAttempts, lockoutStatus, role) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    member1 = ('rmatthews', 'Richard', 'Matthews', 'abc@gmail.com', password1, 0, 0, 'Turnstile')
    member2 = ('mjackson', 'Mary', 'Jackson', 'def@gmail.com', password2, 0, 0, 'Lights Admin')
    member3 = ('psmith', 'Patrick', 'Smith', 'ghi@gmail.com', password3, 0, 0, 'Screen')
    member4 = ('jmitchell', 'Jodie', 'Mitchell', 'jkl@gmail.com', password4, 0, 0, 'CCTV')
    member5 = ('ljones', 'Liam', 'Jones', 'mno@gmail.com', password5, 0, 0, 'Admin')
    curs.execute(sql, member1)
    curs.execute(sql, member2)
    curs.execute(sql, member3)
    curs.execute(sql, member4)
    curs.execute(sql, member5)
    conn.commit()
    # Logs the transaction in python.log.
    with open("db.log", "a") as output_file:
        today = datetime.now()
        dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
        output_file.writelines("Database Reset @ " + str(dtstamp) + "\n")
    print("\nDatabase rebuilt and passwords set.  Enter build_stadium.cmd when ready to continue.")


def check_password(checkpassword):
    """Checks password complexity requirements are met.  E.g. min 8 characters, max 30 characters."""
    # Allowable special characters.
    specialchars = ["‘", "~", "!", "@", "#", "$", "%", "^", "*", "_", "-", "+", "=", "{", "}", "/", ".", "?", "|", " "]
    special = 0
    digitcnt = 0
    lowercnt = 0
    uppercnt = 0
    invalidchar = 0
    pwdlen = len(checkpassword)
    if pwdlen < 8 or pwdlen > 30:
        pwdstatus = "Wrong Length, password must be between 8 and 30 characters"
    else:
        # Counters for calculation to see if at least 3 of the 4 character groups are involved in building password.
        for char in checkpassword:
            if char.isdigit():
                digitcnt = 1
            elif char.isupper():
                uppercnt = 1
            elif char.islower():
                lowercnt = 1
            elif char in specialchars:
                special = 1
            else:
                invalidchar = 1
        mytotal = lowercnt + uppercnt + digitcnt + special
        if invalidchar == 1:
            pwdstatus = "Password contains an illegal character"
        else:
            if mytotal < 3:
                # Not enough character groups in password
                pwdstatus = "Password must contain 3 of the 4 character groups (digit 0-9, uppercase a-z, lowercase a-z, special)"
            else:
                pwdstatus = "Valid"
    return(pwdstatus)


password1 = ""
password2 = ""
password3 = ""
password4 = ""
password5 = ""


register()





