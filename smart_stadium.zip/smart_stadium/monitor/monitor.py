"""Monitor receives and displays online status from IoT devices.
It also allows a prompt to test network connections to other devices using ping,
and to access the Automated Lighting Controls via SSH.
"""

import time
from datetime import datetime
import getpass
from colorama import Fore, Style
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet
from pythonping import ping
from fabric import Connection


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nConnected")
        # Call function to subscribe to the following TOPICS with QOS = 1
        sub(client, TOPIC1, QOSS)
        sub(client, TOPIC2, QOSS)
        sub(client, TOPIC3, QOSS)
        sub(client, TOPIC4, QOSS)
        sub(client, TOPIC5, QOSS)
        sub(client, TOPIC6, QOSS)
        sub(client, TOPIC7, QOSS)
        sub(client, TOPIC8, QOSS)
        sub(client, TOPIC9, QOSS)
        sub(client, TOPIC10, QOSS)
        sub(client, TOPIC11, QOSS)
        sub(client, TOPIC12, QOSS)
    else:
        print("\nNot connected")


def sub(client, topic, qos):
    """Subscribe to TOPICS with QOS = 1."""
    client.subscribe(topic, qos)


def on_message(client, userdata, message):
    """On receiving a message:  decrypt it and display received messages."""
    decrypted_message = CIPHER.decrypt(message.payload)
    msg = str(decrypted_message.decode("utf-8"))
    if msg == "HELP" or msg == "help":
        # Emergency alert from Fire and Emergency Management
        print(Fore.RED, msg)
        print("\n !!!Emergency alarm sounded.  Investigate immediately!!!")
        print(Style.RESET_ALL)
    elif msg in ["Fire and Emergency Management Offline", "CCTV Offline", "Kiosk Offline", "Electric Vehicle Charging Station Offline", "Small Unmanned Aircraft System Offline", "Video Board and PA System Offline", "Automated Lighting Controls Offline", "Telecommunications Offline", "Smart Grid Offline", "HVAC Offline", "POS Offline", "Stadium Entrance Equipment Offline"]:
        # Display specific device offline message in red
        print(Fore.RED, msg)
        print(Style.RESET_ALL)
    else:
        print(msg)
    # This logs the transaction in monitor.log.
    with open("monitor.log", "a", encoding="utf-8") as output_file:
        lognote = msg
        today = datetime.now()
        dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
        output_file.writelines(lognote + " @ " + str(dtstamp) + "\n")


# Set Constants
QOSS = 1
BROKER = "3.64.122.91"
PORT = 1883
TOPIC1 = "cctvstatus"
TOPIC2 = "emergencystatus"
TOPIC3 = "kioskstatus"
TOPIC4 = "evchargingstatus"
TOPIC5 = "suasstatus"
TOPIC6 = "videoboardstatus"
TOPIC7 = "lightsstatus"
TOPIC8 = "telecommsstatus"
TOPIC9 = "smartgridstatus"
TOPIC10 = "hvacstatus"
TOPIC11 = "posstatus"
TOPIC12 = "entrancestatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)


# Define client device
client = mqtt.Client("Central Control Monitor")


# Check network connection, then connect to broker and register callbacks to functions
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
    client.on_message = on_message
except:
    print("No network connection, exiting")
    exit()


while True:
    # Check message buffers
    client.loop_start()
    time.sleep(1)
    # Offer opportunity to test a connection to another node (p) or to open SSH connection to lights
    inp = input("\nPress P to ping any address, or S to open SSH tunnel to lights.\n")
    if inp == "p":
        try:
            pinginp = input("\nPing selected.  Enter address to ping: \n\n")
            ping(pinginp, verbose = True)
        except:
            print("DNS address not found, please try again")
    elif inp == "s":
        print("\nSSH selected.  Connecting to lights. \n")
        try:
            # Gather authentication details
            sshuser = input("Enter username: ")
            sshpass = getpass.getpass("Enter password: ")
            sshconn = Connection(host = sshuser + "@lights", \
            connect_kwargs = {"password" : sshpass})
            # Silently test connection, if successful print Connected as username
            sshconn.run("echo")
            print("Connected as: ")
            sshconn.run("whoami")
            while True:
                try:
                    # Get user inputted ssh command
                    sshcmd = input("\nEnter command (enter 'exit' to return to monitor): ")
                    if sshcmd == 'exit':
                        # If exit entered, return to main menu
                        print("\nExiting SSH connection.")
                        break
                    else:
                        # Run SSH commands remotely on lights
                        sshconn.run(sshcmd)
                except:
                    print("\nInvalid command, please try again")
        except:
            # Lights is uncontactable or invalid credentials provided
            print("\nAuthentication failed, returning to main menu.")
    else:
        print("\nIncorrect option selected.")
