"""Fire and Emergency Management publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
from datetime import datetime
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet

def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nFire and Emergency Management Connected")
    else:
        print("\nNot connected")


def on_disconnect(client, userdata, r_c):
    """On disconnect, log to file"""
    with open("fireandemergency.log", "a", encoding="utf-8") as output_file:
        lognote = "Fire and Emergency Management disconnected with error " + str(r_c)
        today = datetime.now()
        dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
        output_file.writelines(lognote + " @ " + str(dtstamp) + "\n")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC2"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants
QOSS = 1
BROKER = "3.64.122.91"
PORT = 1883
TOPIC2 = "emergencystatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)


# Define client device
client = mqtt.Client("Fire and Emergency Management")
MESG = "Fire and Emergency Management OK"
LWM = "Fire and Emergency Management Offline"


# Set Last Will message on TOPIC2
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC2,elwm,QOSS,retain=False)


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
except:
    print("No network connection, exiting")
    exit()


# This logs the transaction.
with open("fireandemergency.log", "a", encoding="utf-8") as output_file:
    lognote = "Fire and Emergency Management Successfully connected"
    today = datetime.now()
    dtstamp = today.strftime("%d/%m/%Y %H:%M:%S")
    output_file.writelines(lognote + " @ " + str(dtstamp) + "\n")
pub(client, TOPIC2, MESG, QOSS)


# Check message buffers
client.loop_start()
time.sleep(2)


# Give the user a way to send help (HELP) or end the program (Enter)
while True:
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    elif inp.upper() == "HELP":
        pub(client, TOPIC2, "HELP", QOSS)
        print("\nAlarm triggered.  Enter HELP to sound alarm again if required.")
    else:
        print("\nInvalid command: " + inp)
