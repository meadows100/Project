iptables -I INPUT -p 'icmp' -s monitor -j ACCEPT
iptables -I INPUT -s 127.0.0.1 -j ACCEPT
iptables -I OUTPUT -d 127.0.0.1 -j ACCEPT
iptables -I INPUT -p 'tcp' -s 3.64.122.91 -j ACCEPT
iptables -I OUTPUT -p 'tcp' -d 3.64.122.91 -j ACCEPT
iptables -A INPUT --j DROP