"""Video Board and PA system publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nVideo Board and Public Address (PA) System Connected\n")
    else:
        print("\nVideo Board and Public Address (PA) System Not connected\n")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC6"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants
QOSS = 1
BROKER = "3.64.122.91"
PORT = 1883
TOPIC6 = "videoboardstatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "Video Board and PA System OK"
LWM = "Video Board and PA System Offline"


# Define client device
client = mqtt.Client("Video Board and PA System")


# Set Last Will message on TOPIC6
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC6, elwm, QOSS, retain=False)


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
    pub(client, TOPIC6, MESG, QOSS)
except:
    print("No network connection, exiting")
    exit()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
