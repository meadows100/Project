"""HVAC publishes online/offline status via the public broker 
and sends a last will message in case of ungraceful disconnection
"""

import time
import paho.mqtt.client as mqtt
from cryptography.fernet import Fernet


def on_connect(client, userdata, flags, r_c):
    """Check connection"""
    if r_c == 0:
        print("\nHVAC Connected")
        pub(client, TOPIC10, MESG, QOSS)
    else:
        print("\nHVAC Not connected")


def pub(client, topic, msg, qos):
    """Publish message to TOPIC10"""
    message = str(msg)
    encrypted_message = CIPHER.encrypt(message.encode())
    out_message = encrypted_message.decode()
    client.publish(topic, out_message, qos, False)
    time.sleep(2)


# Set Constants
QOSS = 1
BROKER = "3.64.122.91"
PORT = 1883
TOPIC10 = "hvacstatus"
CIPHER_KEY = b'70JZaJg4c5F7RIOhrSXNjq0Y0iGp1QtBy2gyVMSdHHY='
CIPHER = Fernet(CIPHER_KEY)
MESG = "HVAC OK"
LWM = "HVAC Offline"


# Define client device
client = mqtt.Client("HVAC")


# Set Last Will message on TOPIC10
elwm = CIPHER.encrypt(LWM.encode()).decode()
client.will_set(TOPIC10, elwm, QOSS, retain=False)


# Check network connection, then connect to broker
try:
    client.connect(BROKER, PORT)
    client.on_connect = on_connect
except:
    print("No network connection, exiting")
    exit()


# Check message buffers
client.loop_start()
time.sleep(2)


while True:
    client.loop_start()
    time.sleep(2)
    inp = input("Waiting to continue.  Press ENTER any time to shutdown\n")
    # Give the user a way to end the program
    if inp == "":
        print("Ending")
        client.loop_stop()
        exit()
    else:
        print("Invalid command: " + inp)
